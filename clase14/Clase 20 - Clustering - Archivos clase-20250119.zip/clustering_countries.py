#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 28 10:50:57 2024

@author: mcerdeiro
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn import datasets
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram , cut_tree

#%%
df = pd.read_csv('Country-data.csv')
df.columns
inforacion = df.describe()
X = df.drop(columns = ['country'])
#%%
kmeans_set = {"init":"random", "n_init":10, "max_iter":300, "random_state":42}
resultados = [] # inertia for k cluster
for k in range(1,11):
    kmeans = KMeans(n_clusters=k, **kmeans_set)
    kmeans.fit(X)
    resultados.append(kmeans.inertia_)
#%%

fig , ax = plt.subplots (1, 1, figsize =(8 ,8))
plt.plot(range(1,11), resultados)
ax.set_title("WCSS en función del valor de K");

#%%
k = 4
kmeans = KMeans(n_clusters=k, **kmeans_set)
kmeans.fit(X)
#%%
grupos = kmeans.labels_

grupo0 = [i for i in range(len(grupos)) if grupos[i] == 0]
paisesgrupo0 = df.iloc[grupo0]['country']

grupo1 = [i for i in range(len(grupos)) if grupos[i] == 1]
paisesgrupo1 = df.iloc[grupo1]['country']

grupo2 = [i for i in range(len(grupos)) if grupos[i] == 2]
paisesgrupo2 = df.iloc[grupo2]['country']

grupo3 = [i for i in range(len(grupos)) if grupos[i] == 3]
paisesgrupo3 = df.iloc[grupo3]['country']



