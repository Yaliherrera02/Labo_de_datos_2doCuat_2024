#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 23 08:53:40 2024

@author: rodrigo
"""


import pandas as pd
import numpy as np
from sklearn import linear_model
import matplotlib.pyplot as plt
import seaborn as sns

#%%


data_df = pd.read_csv("datos_roundup.txt", sep=" ")
X = data_df['RU'].values[:,np.newaxis] # porque model.fit pide que el vector de entrada sea 2D
Y = data_df['ID']

model = linear_model.LinearRegression()
model.fit(X, Y)

pendiente = model.coef_
ordenada = model.intercept_
R2 = model.score(X, Y)

x_predecir = [[25],[600],[1500]]
y_predicho = model.predict(x_predecir)




#%%
